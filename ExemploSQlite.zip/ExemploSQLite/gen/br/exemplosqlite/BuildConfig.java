/** Automatically generated file. DO NOT MODIFY */
package br.exemplosqlite;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}